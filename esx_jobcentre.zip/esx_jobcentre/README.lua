---------------------------------
--UI Made by: KurlieDino
--Lua based of esx_joblisting
---------------------------------

--INFO--

Originally made for my server Beyond Limits but have a better/updated version of the job centre but thought Id publish a free UI version for people to use.


Before you get started, Some things you MUST DO:

--SET THE JOB--

Firstly, go to the server/server.lua and change the xPlayer.setJob to the desired job. For example:

xPlayer.setJob('gardener', 0)

*Change the 'gardener' to what job you want. I have them set as job 1, job 2 etc. Make sure to make the pictures to the desired job.

--------------------------------------------------------------------------------------------------------------------------------------

--CHANGE THE PICTURES--

Go to the html/img folder to change the pictures. This can be anything you want. Try to match the size of the pictures to the templates given.

--------------------------------------------------------------------------------------------------------------------------------------------

--CHANGING COLOURS--


Most of this is in the hmtl file = "jobui.html"

I suggest open in Visual Studio Code to see the colour and what you can change it too

-------------------------------------------------------------------------------------------------------------------------------------------------

--EXTRA INFO--

You may edit, change, moditfy however you want. DO NOT resell, or pass of as your own.

If you do modify and want to publish for other people, please get my permission first via Discord: KurlieDino#3605

Not much support will be given on this since it is a basic update. I may update down the line to a better UI, more optimised and overall better version. 