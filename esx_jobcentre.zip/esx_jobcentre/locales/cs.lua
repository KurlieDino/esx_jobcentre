Locales['cs'] = {
  ['new_job'] = 'mate novou praci!',
  ['access_job_center'] = 'stiskni ~INPUT_PICKUP~ pro pristup na ~b~Urad prace~s~.',
  ['job_center'] = 'Urad prace',
}
