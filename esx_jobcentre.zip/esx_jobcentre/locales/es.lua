Locales['es'] = {
  ['new_job'] = '¡Tienes un trabajo nuevo!',
  ['access_job_center'] = 'Pulsa ~INPUT_PICKUP~ para entrar a la ~b~Oficina de Empleo~s~.',
  ['job_center'] = 'Oficina de Empleo',
}
